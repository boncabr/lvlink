rootProject.name = "LavaDSPX-Plugin"
