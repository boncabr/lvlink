package moe.kyokobot.koe.internal;

import moe.kyokobot.koe.*;
import moe.kyokobot.koe.codec.CodecInstance;
import moe.kyokobot.koe.codec.CodecType;
import moe.kyokobot.koe.codec.OpusCodecInfo;
import moe.kyokobot.koe.experimental.MediaConnectionExperimental;
import moe.kyokobot.koe.experimental.media.VideoFrameProvider;
import moe.kyokobot.koe.gateway.MediaGatewayConnection;
import moe.kyokobot.koe.gateway.MediaValve;
import moe.kyokobot.koe.handler.ConnectionHandler;
import moe.kyokobot.koe.media.AudioFrameProvider;
import moe.kyokobot.koe.poller.AbstractFramePoller;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;
import java.util.concurrent.CompletionStage;

public class MediaConnectionImpl implements MediaConnection, MediaConnectionExperimental {
    private static final Logger logger = LoggerFactory.getLogger(MediaConnectionImpl.class);

    private final KoeClientImpl client;
    private final long guildId;
    private final EventDispatcher dispatcher;

    private MediaGatewayConnection gatewayConnection;
    private ConnectionHandler<?> connectionHandler;
    private VoiceServerInfo info;
    private CodecInstance audioCodec;
    private CodecInstance videoCodec;
    private AbstractFramePoller audioPoller;
    private AbstractFramePoller videoPoller;
    private AudioFrameProvider audioSender;
    private VideoFrameProvider videoSender;
    private DAVEManager daveManager;

    public MediaConnectionImpl(@NotNull KoeClientImpl client, long guildId) {
        this.client = Objects.requireNonNull(client);
        this.guildId = guildId;
        this.dispatcher = new EventDispatcher();
        this.audioCodec = OpusCodecInfo.INSTANCE.instantiate();
        this.audioPoller = client.getOptions().getFramePollerFactory().createFramePoller(this.audioCodec, this);
        this.videoCodec = null;
        this.videoPoller = null;
    }

    @Override
    public CompletionStage<Void> connect(VoiceServerInfo info) {
        this.disconnect();
        this.createDAVEManager();

        var gatewayFactory = client.getGatewayVersion().getFactory();
        var conn = gatewayFactory.create(this, info);

        return conn.start().thenAccept(nothing -> {
            MediaConnectionImpl.this.info = info;
            MediaConnectionImpl.this.gatewayConnection = conn;

            MediaValve valve = conn.getValve();
            if (valve != null && getOptions().isDeafened()) {
                valve.setDeafen(true);
            }
        });
    }

    @Override
    public void disconnect() {
        logger.debug("Disconnecting...");
        stopAudioFramePolling();
        stopVideoFramePolling();

        if (gatewayConnection != null && gatewayConnection.isOpen()) {
            gatewayConnection.close(1000, null);
            gatewayConnection = null;
        }

        if (connectionHandler != null) {
            connectionHandler.close();
            connectionHandler = null;
        }

        this.destroyDAVEManager();
    }

    @Override
    public void reconnect() {
        logger.debug("Reconnecting...");

        if (gatewayConnection != null) {
            gatewayConnection.reconnect();
        }
    }

    @Override
    @NotNull
    public KoeClient getClient() {
        return client;
    }

    @Override
    @NotNull
    public KoeOptions getOptions() {
        return client.getOptions();
    }

    @Override
    @Nullable
    public AudioFrameProvider getAudioSender() {
        return audioSender;
    }

    @Override
    @Nullable
    public VideoFrameProvider getVideoSender() {
        return videoSender;
    }

    @Override
    public long getGuildId() {
        return guildId;
    }

    @Override
    @Nullable
    public MediaGatewayConnection getGatewayConnection() {
        return gatewayConnection;
    }

    @Override
    @Nullable
    public VoiceServerInfo getVoiceServerInfo() {
        return info;
    }

    @Override
    public ConnectionHandler<?> getConnectionHandler() {
        return connectionHandler;
    }

    @Override
    public void setAudioSender(@Nullable AudioFrameProvider sender) {
        if (this.audioSender != null) {
            this.audioSender.dispose();
        }
        this.audioSender = sender;
        if (sender != null && this.audioCodec != null) {
            sender.onCodecChanged(this.audioCodec);
        }
    }

    @Override
    public void setAudioCodec(@NotNull CodecInstance audioCodec) {
        if (Objects.requireNonNull(audioCodec).getType() != CodecType.AUDIO) {
            throw new IllegalArgumentException("Specified codec must be an audio codec!");
        }

        boolean wasPolling = this.audioPoller != null && this.audioPoller.isPolling();
        this.stopAudioFramePolling();

        this.audioCodec = audioCodec;
        this.audioPoller = client.getOptions().getFramePollerFactory().createFramePoller(audioCodec, this);
        if (this.audioSender != null) {
            this.audioSender.onCodecChanged(audioCodec);
        }

        if (wasPolling) {
            this.startAudioFramePolling();
        }
    }

    @Override
    public void startAudioFramePolling() {
        if (this.audioPoller == null || this.audioPoller.isPolling()) {
            return;
        }

        this.audioPoller.start();
    }

    @Override
    public void stopAudioFramePolling() {
        if (this.audioPoller == null || !this.audioPoller.isPolling()) {
            return;
        }

        this.audioPoller.stop();
    }

    @Override
    public void setVideoSender(@Nullable VideoFrameProvider sender) {
        if (this.videoSender != null) {
            this.videoSender.dispose();
        }
        this.videoSender = sender;
        if (sender != null && this.videoCodec != null) {
            sender.onCodecChanged(this.videoCodec);
        }
    }

    @Override
    public void setVideoCodec(@Nullable CodecInstance videoCodec) {
        if (videoCodec == null) {
            this.stopVideoFramePolling();
            this.videoCodec = null;
            this.videoPoller = null;
            return;
        }

        if (videoCodec.getType() != CodecType.VIDEO) {
            throw new IllegalArgumentException("Specified codec must be a video codec!");
        }

        boolean wasPolling = videoPoller != null && videoPoller.isPolling();
        this.stopVideoFramePolling();

        this.videoCodec = videoCodec;
        this.videoPoller = client.getOptions().getFramePollerFactory().createFramePoller(videoCodec, this);
        if (this.videoSender != null) {
            this.videoSender.onCodecChanged(videoCodec);
        }

        if (wasPolling) {
            this.startVideoFramePolling();
        }
    }

    @Override
    public void startVideoFramePolling() {
        if (this.videoPoller == null || this.videoPoller.isPolling()) {
            return;
        }

        this.videoPoller.start();
    }

    @Override
    public void stopVideoFramePolling() {
        if (this.videoPoller == null || !this.videoPoller.isPolling()) {
            return;
        }

        this.videoPoller.stop();
    }

    @Override
    public void registerListener(KoeEventListener listener) {
        dispatcher.register(listener);
    }

    @Override
    public void unregisterListener(KoeEventListener listener) {
        dispatcher.unregister(listener);
    }

    @Override
    public void close() {
        if (this.audioSender != null) {
            this.audioSender.dispose();
            this.audioSender = null;
        }

        if (this.videoSender != null) {
            this.videoSender.dispose();
            this.videoSender = null;
        }

        disconnect();
        client.removeClosedConnection(this);
    }

    @Override
    public void updateSpeakingState(int mask) {
        if (this.gatewayConnection != null) {
            this.gatewayConnection.updateSpeaking(mask);
        }
    }

    public EventDispatcher getDispatcher() {
        return dispatcher;
    }

    public void setConnectionHandler(ConnectionHandler<?> connectionHandler) {
        this.connectionHandler = connectionHandler;
    }

    public DAVEManager getDAVEManager() {
        return daveManager;
    }

    public void createDAVEManager() {
        this.destroyDAVEManager();

        var daveFactory = client.getDaveFactory();
        if (daveFactory != null) {
            daveManager = new DAVEManager(this, daveFactory);
        }
    }

    public void destroyDAVEManager() {
        if (this.daveManager != null) {
            try {
                this.daveManager.close();
            } catch (Exception e) {
                logger.error("Error closing old DAVE manager", e);
            }
        }
    }
}
